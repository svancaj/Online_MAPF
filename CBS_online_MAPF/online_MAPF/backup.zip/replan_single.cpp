#include "replan_single.h"

using namespace std;

typedef unordered_multimap<int,State*> MyMap;

ReplanSingle::ReplanSingle(Instance* inst, bool b, bool cat)
{
	use_betweenness = b;
	use_cat = cat;
	instance = inst;
	//plan_file = "single_plan.tmp";
	if (b)
		statistic_file = "results_replan_single_betw.st";
	else
	{
		if (cat)
			statistic_file = "results_replan_single_cat.st";
		else
			statistic_file = "results_replan_single.st";
	}
	current_plan = instance->initial_plan;
	if (current_plan.size() > 0)
		current_plan_length = current_plan[0].size();
	else
		current_plan_length = 0;
}

int ReplanSingle::Solve()
{
	for (int i = instance->agents; i < instance->agents + instance->new_agents; i++)
	{
		long long runtime = 0;

		conflict_avoidance_table = vector<int> (instance->nodes, 0);
		for (size_t j = 0; j < current_plan.size(); j++)
		{
			for (size_t k = (size_t)instance->appear[i]; k < current_plan[j].size(); k++)
			{
				if (current_plan[j][k] >= 0)
					conflict_avoidance_table[current_plan[j][k]]++;
			}
		}

		single_plan.clear();
		fringe = priority_queue<State*, vector<State*>, pgreater> ();
		chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();

		/*pid_t worker_pid = fork();
		if (worker_pid == 0)
		{
			FindPath(instance->start[i], instance->goal[i], instance->appear[i]);
			exit(0);
		}

		pid_t timeout_pid = fork();
		if (timeout_pid == 0)
		{
			sleep(instance->timeout);
			exit(0);
		}
		pid_t exited_pid = wait(NULL);
		if (exited_pid == worker_pid)
			kill(timeout_pid, SIGKILL);
		else
			kill(worker_pid, SIGKILL); // Or something less violent if you prefer*/

		FindPath(instance->start[i], instance->goal[i], instance->appear[i]);

		chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
		runtime = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin).count();
		replan_times.push_back(runtime);

		//wait(NULL);

		if (runtime > instance->timeout * 1000)
		{
			instance->PrintStatistic(statistic_file, string("RS"), instance->ComputeSoC(current_plan), 0, true, replan_times);
			return -1;
		}

		MergePlans(i, instance->appear[i]);
	}
	instance->PrintStatistic(statistic_file, string("RS"), instance->ComputeSoC(current_plan), 0, false, replan_times);

	//instance->PrintPlan(current_plan);
	instance->CheckPlan(current_plan);
	
	/*string executable = "del /f ";
	executable.append(plan_file);
	system(executable.c_str());*/
	
	return 0;
}

void ReplanSingle::FindPath(int from, int to, int time)
{
	int garage = -2;
	State* first = new State();
	first->node = garage;
	first->destination = to;
	first->distance = instance->distance[from][to] + 1;
	first->time = 0;
	first->parent = NULL;
	if (use_betweenness)
		first->betweenness = 1;
	else
		first->betweenness = -1;
	if (use_cat)
		first->cat = 0;
	else
		first->cat = -1;

	open_nodes.insert(MyMap::value_type(first->node * first->time, first));
	fringe.push(first);

	State* current_state;

	while (!fringe.empty())
	{
		current_state = fringe.top();
		fringe.pop();

		// remove current_state from open
		auto its = open_nodes.equal_range(current_state->node * current_state->time);
		for (auto it = its.first; it != its.second; ++it)
		{
			if (current_state == it->second)
			{
				open_nodes.erase(it);
				break;
			}
		}

		closed_nodes.insert(MyMap::value_type(current_state->node * current_state->time, current_state));

		if (current_state->node == to)
		{
			ConstructPath(current_state);
			return;
		}

		GetChildren(current_state, from, time);
	}
}

void ReplanSingle::GetChildren(State* current_state, int from, int start_time)
{
	int parent_node = current_state->node;
	int parent_time = current_state->time;

	if (parent_node == -2)
		AddIfCan(current_state, from, parent_time + 1, start_time);
	else
		for (size_t i = 0; i < instance->graph[parent_node].size(); i++)
			AddIfCan(current_state, instance->graph[parent_node][i], parent_time + 1, start_time);

	AddIfCan(current_state, parent_node, parent_time + 1, start_time);
}

void ReplanSingle::AddIfCan(State* parent, int node, int time, int start_time)
{
	// is there a node colision?
	int time_in_plan = start_time + time;
	for (size_t i = 0; i < current_plan.size(); i++)
		if (node != -2 && time_in_plan < (int)current_plan[i].size() && current_plan[i][time_in_plan] == node)
			return;

	// is there a swap colision?
	for (size_t i = 0; i < current_plan.size(); i++)
		if (node != -2 && time_in_plan < (int)current_plan[i].size() && current_plan[i][time_in_plan] == parent->node && current_plan[i][time_in_plan - 1] == node)
			return;

	// is it in open?
	auto its1 = open_nodes.equal_range(node * time);
	for (auto it = its1.first; it != its1.second; ++it)
		if (node == it->second->node && time == it->second->time)
			return;

	// is it in closed?
	auto its2 = closed_nodes.equal_range(node * time);
	for (auto it = its2.first; it != its2.second; ++it)
		if (node == it->second->node && time == it->second->time)
			return;

	// add
	State* tmp = new State();
	tmp->node = node;
	tmp->destination = parent->destination;
	if (tmp->node == -2)
		tmp->distance = parent->distance;
	else
		tmp->distance = instance->distance[tmp->node][tmp->destination];
	tmp->time = time;
	tmp->parent = parent;
	if (parent->betweenness >= 0)
	{
		if (node == -2)
			tmp->betweenness = 1;
		else
			tmp->betweenness = instance->betweenness[node];
	}
	else
		tmp->betweenness = -1;
	if (parent->cat >= 0)
	{
		if (node == -2)
			tmp->cat = 0;
		else
			tmp->cat = conflict_avoidance_table[node];
	}
	else
		tmp->cat = -1;

	open_nodes.insert(MyMap::value_type(tmp->node * tmp->time, tmp));
	fringe.push(tmp);
}

void ReplanSingle::ConstructPath(State* current_state)
{
	vector<int> path;
	while (current_state != NULL)
	{
		path.push_back(current_state->node);
		current_state = current_state->parent;
	}

	for (int i = (int)path.size() - 1; i >= 0; i--)
		single_plan.push_back(path[i]);

	/*ofstream out;
	out.open(plan_file);
	out << single_plan.size() << endl;
	for (size_t i = 0; i < single_plan.size(); i++)
		out << single_plan[i] << " ";
	out << endl;
	out.close();*/

	// also clean all states, we do not need them any more
	for (auto it = open_nodes.begin(); it != open_nodes.end(); ++it)
		delete it->second;
	for (auto it = closed_nodes.begin(); it != closed_nodes.end(); ++it)
		delete it->second;
	open_nodes.clear();
	closed_nodes.clear();
}

void ReplanSingle::MergePlans(int agent, int time)
{
	/*ifstream in;
	in.open(plan_file);

	int i_max, tmp_location;
	string s_dump;

	in >> i_max;

	getline(in, s_dump);	// get rid of empty line

	for (int i = 0; i < i_max; i++)
	{
		in >> tmp_location;
		single_plan.push_back(tmp_location);
	}

	in.close();*/

	int plan_length = max((int)(time + single_plan.size()), current_plan_length);
	current_plan.push_back(vector<int> (plan_length, -1));

	if (plan_length > current_plan_length)
		for (size_t i = 0; i < current_plan.size(); i++)
			current_plan[i].resize(plan_length, -1);

	current_plan_length = plan_length;

	for (size_t i = 0; i < single_plan.size(); i++)
		current_plan[agent][i + time] = single_plan[i];
}
